function main() {
    console.log("hello world!");
}

main();
